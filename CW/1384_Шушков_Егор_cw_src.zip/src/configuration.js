export let SPEED = 3;
export let MAP_WIDTH = 640;
export let MAP_HEIGHT = 640; 
export let TILE_SIZE = 32;
export let ZOMBIE_TIME_SPAWN = 100; 
